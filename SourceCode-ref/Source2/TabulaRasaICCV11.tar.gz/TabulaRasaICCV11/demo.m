% This is a demo file that shows how to use A-SVM, PMT-SVM, DA-SVM
% on a simple classification example. Images are extracted from PASCAL VOC
% 2007 dataset. Task is to learn a bicycle classifier by transferring
% information from motorbike classifier via the guidance of a few bicycle
% samples.

% Please see the publication below for more information:
% Y. Aytar, A. Zisserman
% Tabula Rasa: Model Transfer for Object Category Detection
% IEEE International Conference on Computer Vision, 2011

% MOSEK optimization toolkit is advised for faster QP optimization which is
% used in Model Transfer SVM learning procedures.

addpath svms
addpath utils


if (exist('features.mat'))
    load features.mat    
else    
    sourceClass = 'motorbike';
    targetClass = 'bicycle';
    
    % read source(motorbike) and target(bicycle) samples
    fprintf('Reading source and target samples.\n');
    source.trn.posImgs = readImages(['data/' sourceClass '/train/positive']);
    source.trn.negImgs= readImages(['data/' sourceClass '/train/negative']);
    target.trn.posImgs = readImages(['data/' targetClass '/train/positive']);
    target.trn.negImgs= readImages(['data/' targetClass '/train/negative']);
    target.test.posImgs= readImages(['data/' targetClass '/test/positive']);
    target.test.negImgs= readImages(['data/' targetClass '/test/negative']);
    
    % shuffle target training samples
    sh = randperm(length(target.trn.posImgs));
    target.trn.posImgs = target.trn.posImgs(sh);
    
    % extract hog features and assign labels
    fprintf('Extracting features.\n');
    source.trn.features = [extractHOGFeatures(source.trn.negImgs);extractHOGFeatures(source.trn.posImgs)];
    source.trn.labels = [-ones(length(source.trn.posImgs),1);ones(length(source.trn.negImgs),1)];
    target.trn.features = [extractHOGFeatures(target.trn.negImgs);extractHOGFeatures(target.trn.posImgs)];
    target.trn.labels = [-ones(length(target.trn.posImgs),1);ones(length(target.trn.negImgs),1)];
    target.test.features = [extractHOGFeatures(target.test.negImgs);extractHOGFeatures(target.test.posImgs)];
    target.test.labels = [-ones(length(target.test.posImgs),1);ones(length(target.test.negImgs),1)];
    
    % save computed features
    save('features.mat','source','target','sourceClass','targetClass');    
end


% geometric structure of HOG features - mainly needed for DA-SVM
H=8;  % height of HOG cell grid
W=13; % width of HOG cell grid
D=32; % number of features in each cell

C=0.002; % error weight in SVMs


%% Train source classifier
% Given a zero vector as the source, A-SVM converges to the classical SVM
% formulation. Thus we use A-SVM for training an SVM classifier. 

fprintf('Training source classifier.\n');
ws_zero = zeros(H*W*D,1);
source.svm = A_SVM(source.trn.labels,source.trn.features,C,ws_zero);
scores = target.test.features*source.svm.w+source.svm.b;
ap_source = computeAP(scores,target.test.labels);
source.svm.w = source.svm.w/norm(source.svm.w(:)); % l2 normalization


%% Train & test target classifier with increasing number of samples

fprintf('Transfer training and testing for...\n');

MaxSample = length(target.trn.posImgs);
APs = [];
negCount = length(target.trn.negImgs);
stepSize = 5;
for i=1:stepSize:MaxSample
    
    fprintf('\t %d sample(s)\n',i);
    pause(0.001);
    
    idx = [1:i,negCount+1:negCount+i];    % balanced positive and negative samples
%         idx = [1:negCount+i];  % unbalanced positive and negative samples
    
    
    % target SVM trained with using target samples only
    target.svm = A_SVM(target.trn.labels(idx),target.trn.features(idx,:),C,ws_zero);
    scores = target.test.features*target.svm.w+target.svm.b;
    APs(ceil(i/stepSize),1) = computeAP(scores,target.test.labels);
    
    % A-SVM
    target.a_svm = A_SVM(target.trn.labels(idx),target.trn.features(idx,:),C,source.svm.w);
    scores = target.test.features*target.a_svm.w+target.a_svm.b;
    APs(ceil(i/stepSize),2) = computeAP(scores,target.test.labels);
    
    % PMT-SVM
    target.pmt_svm = PMT_SVM(target.trn.labels(idx),target.trn.features(idx,:),C,source.svm.w);
    scores = target.test.features*target.pmt_svm.w+target.pmt_svm.b;
    APs(ceil(i/stepSize),3) = computeAP(scores,target.test.labels);
    
    % DA-SVM
    wsource3D = reshape(source.svm.w,H,W,D);
    target.da_svm = DA_SVM(target.trn.labels(idx),target.trn.features(idx,:),C,wsource3D);
    scores = target.test.features*target.da_svm.w+target.da_svm.b;
    APs(ceil(i/stepSize),4) = computeAP(scores,target.test.labels);
end


% Draw comparison figure between SVM, A-SVM, DA-SVM, PMT-SVM
fprintf('Drawing the AP curves.\n');
drawComparisonFigure( ['Source: ' sourceClass  '      Target: ' targetClass  ] , ...
    [1:stepSize:MaxSample],{ ...
    APs(:,4),['DA-SVM']; ...
    APs(:,3),['PMT-SVM']; ...
    APs(:,2),['A-SVM']; ...
    APs(:,1),['SVM (' targetClass ')']; ...
    ones(length(1:stepSize:MaxSample),1)*ap_source,['Source SVM (' sourceClass ')']; ...
    });
