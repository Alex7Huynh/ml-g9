function [images] = readImages(folder,MAX_IMG)

if nargin < 2
    MAX_IMG = 1000;
end

images = {};
for i=1:MAX_IMG 
    fileName = sprintf('%s/%03d.jpg',folder,i);
    if (~exist(fileName))
        break;
    end
    images{i} = imread(fileName);
end